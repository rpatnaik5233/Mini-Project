package com.cg.dao;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;




public class ParticipantsDAOImpl implements IParticipantsDAO {

	@Override
	public boolean participantFeedback(FeedbackMasterBean feedBack)
			throws FeedBackException {
	
		return false;
	}

	@Override
	public String retrieveTrCode(String employeeCode) {
		
		return null;
	}

	
}



