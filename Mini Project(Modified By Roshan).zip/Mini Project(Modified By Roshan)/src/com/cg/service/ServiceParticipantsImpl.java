package com.cg.service;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public class ServiceParticipantsImpl implements IServiceParticipants {

	@Override
	public boolean participantFeedback(FeedbackMasterBean feedBack)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public String retrieveTrCode(String employeeCode) {
		// TODO Auto-generated method stub
		return null;
	}

}
