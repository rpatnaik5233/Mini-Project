package com.cg.service;

import java.util.List;

import com.cg.bean.CourseMasterBean;
import com.cg.bean.FacultySkillBean;
import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public class ServiceTrainingAdminImpl implements IServiceTrainingAdmin {

	@Override
	public boolean facultyMaintenance(FacultySkillBean faculty)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean courseMaintenance(CourseMasterBean course)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<FacultySkillBean> viewFaculty() throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean updateFaculty(FacultySkillBean faculty)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean deleteFaculty(String facultyCode) throws FeedBackException {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public List<FeedbackMasterBean> viewFacultyWiseReport(int month)
			throws FeedBackException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public FacultySkillBean retrieveFaculty(String facultyCode) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public String retrieveFacultyCode(String trainingCode) {
		// TODO Auto-generated method stub
		return null;
	}
	
	

}
