package com.cg.service;

import com.cg.bean.FeedbackMasterBean;
import com.cg.exception.FeedBackException;

public interface IServiceParticipants {

	public boolean participantFeedback(FeedbackMasterBean feedBack) throws  FeedBackException;
	public String retrieveTrCode(String employeeCode);
}
