package com.cg.exception;

public class FeedBackException extends Exception 
{

	/**
	 * 
	 */
	private static final long serialVersionUID = 4473513424240627536L;
	
	public FeedBackException()
	{
		//For good programming practice add super 
		super();
	}

	public FeedBackException(String message) 
	{
		super(message);
		
	}

}
